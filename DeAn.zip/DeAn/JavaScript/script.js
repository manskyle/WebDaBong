function displayImage(imageSrc) {
  
  
    var selectedImage = document.getElementById('selected-image');
      selectedImage.
      selectedIm
    
      sele
    src = imageSrc;
    }